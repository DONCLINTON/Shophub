const SUPABASE_URL = "https://lulijpkeslesdeyemada.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx1bGlqcGtlc2xlc2RleWVtYWRhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUzMjM1MDMsImV4cCI6MjEwMDg5OTUwM30.ptWL1GF5DrshvF6VhwIs3HjRiA_qWgVlux3uk61Hi_A";
const SITE = "https://shhop.netlify.app";

function slugify(value) {
  return String(value || "listing").normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 75) || "listing";
}
function escapeXml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function escapeJsonLd(value) {
  return JSON.stringify(value).replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/&/g, "\\u0026");
}
async function supabaseRows(table, query) {
  const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${query}`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` }
  });
  if (!response.ok) throw new Error(`Supabase ${table} query failed: ${response.status}`);
  return await response.json();
}
async function fetchAll(table) {
  const all = [];
  for (let start = 0; start < 10000; start += 1000) {
    const rows = await supabaseRows(table, `select=id,title,created_at&order=created_at.desc&limit=1000&offset=${start}`);
    all.push(...rows);
    if (rows.length < 1000) break;
  }
  return all;
}
function htmlResponse(html, upstream, status = upstream.status) {
  const headers = new Headers(upstream.headers);
  headers.delete("content-length");
  headers.delete("content-encoding");
  headers.delete("etag");
  headers.delete("content-md5");
  headers.set("content-type", "text/html; charset=utf-8");
  return new Response(html, { status, headers });
}
function upsertMeta(html, selectorRegex, replacement) {
  return selectorRegex.test(html) ? html.replace(selectorRegex, replacement) : html.replace("</head>", replacement + "\n</head>");
}
function setMeta(html, {title, description, canonical, image, schema, noindex = false}) {
  const desc = String(description || "ShopHub Uganda marketplace listings and jobs.").replace(/\s+/g, " ").slice(0, 300);
  html = html.replace(/<title>[^<]*<\/title>/i, `<title>${title.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</title>`);
  html = upsertMeta(html, /<meta\s+name=["']description["'][^>]*>/i, `<meta name="description" content="${desc.replace(/&/g, "&amp;").replace(/"/g, "&quot;")}">`);
  html = upsertMeta(html, /<meta\s+name=["']robots["'][^>]*>/i, `<meta name="robots" content="${noindex ? "noindex,follow" : "index,follow,max-image-preview:large"}">`);
  html = upsertMeta(html, /<link\s+rel=["']canonical["'][^>]*>/i, `<link rel="canonical" href="${canonical}">`);
  const og = [
    ["og:title", title], ["og:description", desc], ["og:url", canonical],
    ["og:type", "website"], ["og:image", image || `${SITE}/Icon_512.png`]
  ];
  for (const [name, content] of og) {
    const re = new RegExp(`<meta\\s+property=["']${name}["'][^>]*>`, "i");
    html = upsertMeta(html, re, `<meta property="${name}" content="${String(content).replace(/&/g, "&amp;").replace(/"/g, "&quot;")}">`);
  }
  if (schema) html = html.replace("</head>", `<script type="application/ld+json">${escapeJsonLd(schema)}</script>\n</head>`);
  return html;
}
async function sitemapResponse() {
  const [products, jobs] = await Promise.all([fetchAll("listings"), fetchAll("jobs")]);
  const urls = new Map();
  urls.set(`${SITE}/`, null);
  urls.set(`${SITE}/jobs`, null);
  for (const item of products) {
    if (!item?.id || !item?.title) continue;
    const path = `/product/${encodeURIComponent(item.id)}/${slugify(item.title)}`;
    urls.set(`${SITE}${path}`, item.created_at);
  }
  for (const job of jobs) {
    if (!job?.id || !job?.title) continue;
    const path = `/jobs/${encodeURIComponent(job.id)}/${slugify(job.title)}`;
    urls.set(`${SITE}${path}`, job.created_at);
  }
  const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    [...urls.entries()].map(([loc, date]) => `  <url><loc>${escapeXml(loc)}</loc>${date ? `<lastmod>${new Date(date).toISOString().slice(0,10)}</lastmod>` : ""}<changefreq>weekly</changefreq></url>`).join("\n") +
    `\n</urlset>`;
  return new Response(body, { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=300" } });
}
export default async (request, context) => {
  const url = new URL(request.url);
  if (url.pathname === "/sitemap.xml") {
    try { return await sitemapResponse(); }
    catch (error) {
      console.error("ShopHub sitemap generation failed", error);
      return new Response("ShopHub sitemap is temporarily unavailable. Please retry shortly.", {
        status: 503,
        headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" }
      });
    }
  }

  const path = decodeURIComponent(url.pathname);
  const productMatch = path.match(/^\/product\/([^/]+)(?:\/([^/]+))?\/?$/);
  const jobMatch = path.match(/^\/jobs\/([^/]+)(?:\/([^/]+))?\/?$/);
  const isJobsLanding = /^\/jobs\/?$/.test(path);
  if (!productMatch && !jobMatch && !isJobsLanding) return context.next();

  const upstream = await context.next();
  const contentType = upstream.headers.get("content-type") || "";
  if (!contentType.includes("text/html")) return upstream;
  let html = await upstream.text();

  if (isJobsLanding) {
    html = setMeta(html, { title: "Jobs in Uganda — Find Work | ShopHub Uganda",
      description: "Discover job vacancies in Uganda and international opportunities on ShopHub Uganda. Browse roles, locations and employer details.",
      canonical: `${SITE}/jobs` });
    return htmlResponse(html, upstream);
  }

  try {
    const id = (productMatch || jobMatch)[1];
    const table = productMatch ? "listings" : "jobs";
    const rows = await supabaseRows(table, `select=*&id=eq.${encodeURIComponent(id)}&limit=1`);
    const record = rows?.[0];
    if (!record) {
      html = setMeta(html, { title: "Listing unavailable | ShopHub Uganda",
        description: "This ShopHub listing is no longer available.",
        canonical: `${SITE}${path}`, noindex: true });
      return htmlResponse(html, upstream, 404);
    }
    const canonical = productMatch
      ? `${SITE}/product/${encodeURIComponent(record.id)}/${slugify(record.title)}`
      : `${SITE}/jobs/${encodeURIComponent(record.id)}/${slugify(record.title)}`;
    let schema;
    if (productMatch) {
      const price = Number(String(record.price_num ?? record.price ?? "").replace(/[^0-9.]/g, ""));
      schema = {
        "@context": "https://schema.org", "@type": "Product",
        name: record.title, description: record.description || record.title,
        image: record.image_url || (Array.isArray(record.image_urls) ? record.image_urls[0] : undefined),
        category: record.category,
        url: canonical,
        offers: Number.isFinite(price) && price > 0 ? {
          "@type": "Offer", priceCurrency: "UGX", price: price,
          availability: String(record.status || "").toLowerCase() === "sold"
            ? "https://schema.org/OutOfStock" : "https://schema.org/InStock",
          url: canonical
        } : undefined
      };
    } else if (record.company && record.created_at) {
      schema = {
        "@context": "https://schema.org", "@type": "JobPosting",
        title: record.title, description: record.description || record.title,
        datePosted: record.created_at,
        hiringOrganization: { "@type": "Organization", name: record.company },
        jobLocation: record.location ? { "@type": "Place", address: {
          "@type": "PostalAddress", addressLocality: record.location, addressCountry: "UG"
        } } : undefined,
        url: canonical
      };
    }
    const description = productMatch
      ? [record.title, record.category, record.location, record.description, record.price ? `UGX ${record.price}` : ""].filter(Boolean).join(" — ")
      : [record.title, record.company, record.location, record.job_type, record.description].filter(Boolean).join(" — ");
    const image = productMatch ? (record.image_url || (Array.isArray(record.image_urls) ? record.image_urls[0] : undefined)) : undefined;
    html = setMeta(html, {
      title: `${record.title} | ${productMatch ? "ShopHub Uganda" : "ShopHub Jobs"}`,
      description, canonical, image, schema
    });
    return htmlResponse(html, upstream);
  } catch (error) {
    console.error("ShopHub SEO edge rendering failed", error);
    // Even during a temporary database/API failure, never ship the homepage
    // canonical on a product or job detail URL.
    html = setMeta(html, {
      title: `${productMatch ? "Product listing" : "Job vacancy"} | ShopHub Uganda`,
      description: "View this listing on ShopHub Uganda. Product and job details are loaded from the live marketplace.",
      canonical: `${SITE}${path}`
    });
    return htmlResponse(html, upstream);
  }
};
